<html>
<head>
</head>
<body>
<?php
phpinfo();
?>
</body>
</html>

